// Do not modify this file

public class EmptyListException extends RuntimeException
{
	private static final long serialVersionUID = 1;
	public EmptyListException()
	{
		super();
	}
}