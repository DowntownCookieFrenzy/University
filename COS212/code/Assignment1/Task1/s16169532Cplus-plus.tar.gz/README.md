# Assignment 1
This was godawful.

Why the hell would I ever do this? I get what they
are trying to teach but lawd knows it's a bad idea
to teach it this way.

The moral of this Assignment was DON'T REWRITE CODE.
( unless you have to physically molest a datastructure to support the rewrite )
